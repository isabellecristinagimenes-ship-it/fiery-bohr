// Backend API URL
// In production, this should be an Environment Variable (VITE_API_URL)
// For this template, we default to the known Railway Backend URL
export const API_URL = 'https://fiery-bohr-production-b324.up.railway.app';
